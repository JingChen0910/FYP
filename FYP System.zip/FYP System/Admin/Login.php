<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log-In Page</title>
    <link rel="stylesheet" href="Login.css">
</head>
<body>
    <div class="form">
        <form action="Login.php" method="post">
            <div class="sub">
            <h1>Welcome To Feijip Pharmacy</h1>
            </div>
            <div class="a">
                <input type="text" placeholder="Enter Your ID" name="id" required>
            </div>
            <div class="a">
                <input type="text" placeholder="Enter Your Name" name="name" required>
            </div>
            <div class="a">
                <input type="password" placeholder="Enter Your Password" name="password" required>
            </div>
            <button type="submit" value="login" name="login">Log-In</button>
        </form>
    </div>

    <?php
        if(isset($_POST["login"])){
            $id = $_POST['id'];
            $name = $_POST['name'];
            $password = $_POST['password'];

            require_once "Database.php";

            $sql = "SELECT * FROM admin WHERE id = '$id' AND name = '$name' AND password = '$password'";
            $result = mysqli_query($conection,$sql);

            if(mysqli_num_rows($result) > 0){
                echo "<script>alert('Welcome Admin.');
                window.location.href='AdminPage.html';</script>";
            }
            else{
                require_once "Database.php";
                $sql = "SELECT * FROM superadmin WHERE id = '$id' AND name = '$name' AND password = '$password'";
                $result = mysqli_query($conection,$sql);

                if(mysqli_num_rows($result) > 0){
                    echo "<script>alert('Welcome Super Admin.');
                    window.location.href='SuperAdminPage.html';</script>";
                }
                else{
                    echo "<script>alert('Invalid login credentials. Please try again.');</script>";
                }
            }
        }
    ?>
</body>
</html>